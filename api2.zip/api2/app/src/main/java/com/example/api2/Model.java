package com.example.api2;

import java.util.ArrayList;

public class Model {
    String message;
    String number;
    ArrayList<people> people;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public ArrayList<Model.people> getPeople() {
        return people;
    }

    public void setPeople(ArrayList<Model.people> people) {
        this.people = people;
    }

    public class people{
        String name;
        String craft;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCraft() {
            return craft;
        }

        public void setCraft(String craft) {
            this.craft = craft;
        }
    }
}
