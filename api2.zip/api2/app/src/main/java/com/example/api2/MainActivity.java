package com.example.api2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Button getData;
    Intent doSomethingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getData = findViewById(R.id.getData);
        getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Methods methods = RetrofitClient.getRetrofitInstance().create(Methods.class);
                Call<Model> call = methods.getAllData();

                call.enqueue(new Callback<Model>() {
                    @Override
                    public void onResponse(Call<Model> call, Response<Model> response) {
                        TextView textViewResult = findViewById(R.id.textViewCode);
                       //Log.e(TAG,"onResponse: "+response.code());
                        textViewResult.setText("Code: " + response.code());

                        ArrayList<Model.people> people = response.body().getPeople();

                        TextView textViewNames = findViewById(R.id.textViewNames);
                        for (Model.people people1 : people){
                           // Log.e(TAG, "onResponse: All Names: " + people1.getName() );
                            textViewNames.setText("Code: " + people1.getCraft());
                        }


                    }

                    @Override
                    public void onFailure(Call<Model> call, Throwable t) {
                        Log.e(TAG, "onFailure: "+t.getMessage());
                    }
                });
            }
        });

    }
    public void chooseState (View view){
        doSomethingIntent = new Intent(getApplicationContext(), choose_state.class);
        startActivity(doSomethingIntent);
    }
}