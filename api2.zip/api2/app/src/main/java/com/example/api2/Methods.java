package com.example.api2;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Methods {
    @GET("astros")
    Call<Model> getAllData();
}
