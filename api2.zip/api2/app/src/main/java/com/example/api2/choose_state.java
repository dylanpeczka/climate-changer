package com.example.api2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class choose_state extends AppCompatActivity {

    Intent doSomethingIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_state2);
    }

    public void state (View view){
        doSomethingIntent = new Intent(getApplicationContext(), stateActivity.class);
        startActivity(doSomethingIntent);
    }
}